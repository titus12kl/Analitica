import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


df_twitter = pd.read_csv('reto/arteDeLaAnalitica/covid19_tweets.csv')

# Filtrar datos para usuarios verificados y no verificados
df_verified = df_twitter[df_twitter['user_verified'] == True]
df_not_verified = df_twitter[df_twitter['user_verified'] == False]

mean_verified_followers = df_verified['user_followers'].mean()
mean_not_verified_followers = df_not_verified['user_followers'].mean()

print("Media de seguidores de usuarios verificados:", mean_verified_followers)
print("Media de seguidores de usuarios no verificados:", mean_not_verified_followers)

# Contar el número de usuarios verificados y no verificados
verified_counts = df_twitter['user_verified'].value_counts()

# Calcular el porcentaje de personas verificadas y no verificadas
percentage_verified = (verified_counts[True] / df_twitter.shape[0]) * 100
percentage_not_verified = (verified_counts[False] / df_twitter.shape[0]) * 100

print("Porcentaje de personas verificadas:", percentage_verified)
print("Porcentaje de personas no verificadas:", percentage_not_verified)

# Crear el scatterplot
plt.figure(figsize=(10, 6))
sns.scatterplot(x='user_verified', y='user_followers', data=df_twitter, alpha=0.5)
plt.title('Seguidores de Usuarios Verificados y No Verificados')
plt.xlabel('Usuario Verificado')
plt.ylabel('Número de Seguidores')
plt.xticks([0, 1], ['No Verificado', 'Verificado'])
plt.show()


df_selected = df_twitter[['user_followers', 'user_friends', 'user_favourites']]
# Calcular la correlación entre las columnas
correlation_matrix = df_selected.corr()

# Crear un heatmap de la matriz de correlación
plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Matriz de correlación entre user_followers, user_friends y user_favourites')
plt.show()

# Definir las palabras clave relacionadas con COVID-19
covid_keywords = ['COVID19', 'Covid19', 'coronavirus']

# Convertir valores no válidos en la columna 'hashtags' a cadenas vacías
df_twitter['hashtags'] = df_twitter['hashtags'].fillna('')

# Crear una columna nueva que indique si cada hashtag es relacionado con COVID-19
df_twitter['is_covid_hashtag'] = df_twitter['hashtags'].apply(lambda x: any(keyword.lower() in str(x).lower() for keyword in covid_keywords))

# Filtrar los tweets que contienen hashtags relacionados con COVID-19
df_covid_tweets = df_twitter[df_twitter['is_covid_hashtag']]

# Convertir la columna 'date' a tipo de datos datetime con manejo de errores
df_covid_tweets['date'] = pd.to_datetime(df_covid_tweets['date'], errors='coerce')

# Eliminar filas con valores de fecha y hora no válidos (NaT)
df_covid_tweets = df_covid_tweets.dropna(subset=['date'])

# Extraer el mes y el año de la columna 'date'
df_covid_tweets['month_year'] = df_covid_tweets['date'].dt.to_period('M')

# Contar el número total de tweets sobre COVID-19 por mes/año
tweets_per_month_year = df_covid_tweets.groupby('month_year').size().reset_index(name='count')

print(tweets_per_month_year)

# Graficar el número total de tweets sobre COVID-19 por mes/año
plt.figure(figsize=(12, 6))
sns.barplot(data=tweets_per_month_year, x='month_year', y='count', color='skyblue')
plt.title('Número total de tweets sobre COVID-19 por mes/año')
plt.xlabel('Mes/Año')
plt.ylabel('Número de Tweets')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
