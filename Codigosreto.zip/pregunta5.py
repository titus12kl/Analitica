import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = pd.read_csv('/Users/maxito/Documents/vscode/python/arteDeLaAnalitica/covid19_tweets.csv')

data['mentions_covid'] = data['text'].str.contains('covid|COVID|Covid', na=False) | data['hashtags'].str.contains('covid|COVID|Covid', na=False)

user_covid_tweets = data.groupby('user_name')['mentions_covid'].sum()

data_merged = data.merge(user_covid_tweets.rename('covid_tweet_count'), on='user_name')

average_covid_tweets_by_friends = data_merged.groupby('user_friends')['covid_tweet_count'].mean().reset_index()

plt.figure(figsize=(10, 6))
sns.scatterplot(data=average_covid_tweets_by_friends, x='user_friends', y='covid_tweet_count', alpha=0.6)
plt.xscale('log')  
plt.yscale('log')
plt.title('Relación entre Número de Amigos y Media de Tweets sobre COVID-19 por Usuario')
plt.xlabel('Número de Amigos (escala logarítmica)')
plt.ylabel('Media de Tweets sobre COVID-19 (escala logarítmica)')
plt.show()
