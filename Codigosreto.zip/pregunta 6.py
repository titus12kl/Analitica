import pandas as pd

data = pd.read_csv('/Users/maxito/Documents/vscode/python/arteDeLaAnalitica/covid19_tweets.csv')

data['mentions_covid'] = data['text'].str.contains('covid|COVID|Covid', na=False) | data['hashtags'].str.contains('covid|COVID|Covid', na=False)

covid_tweets_by_verification = data.groupby('user_verified')['mentions_covid'].sum()

total_tweets_by_verification = data.groupby('user_verified').size()

proportion_of_covid_tweets = covid_tweets_by_verification / total_tweets_by_verification
percent_covid_verified = proportion_of_covid_tweets[True] * 100
percent_covid_non_verified = proportion_of_covid_tweets[False] * 100
print("Porcentaje de tweets sobre COVID-19 por usuarios verificados: {:.2f}%".format(percent_covid_verified))
print("Porcentaje de tweets sobre COVID-19 por usuarios no verificados: {:.2f}%".format(percent_covid_non_verified))
