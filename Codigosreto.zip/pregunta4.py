import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Cargar datos
data = pd.read_csv('/Users/maxito/Documents/vscode/python/arteDeLaAnalitica/covid19_tweets.csv')

data['has_hashtags'] = data['hashtags'].notna()

hashtag_proportion = data['has_hashtags'].value_counts(normalize=True)
percent_with_hashtags = hashtag_proportion[True] * 100
percent_without_hashtags = hashtag_proportion[False] * 100
print("Porcentaje de tweets con hashtags: {:.2f}%".format(percent_with_hashtags))
print("Porcentaje de tweets sin hashtags: {:.2f}%".format(percent_without_hashtags))

data['mentions_covid'] = data['text'].str.contains('covid|COVID|Covid', na=False) | data['hashtags'].str.contains('covid|COVID|Covid', na=False)

user_covid_tweets = data.groupby('user_name')['mentions_covid'].sum()

data_merged = data.merge(user_covid_tweets.rename('covid_tweet_count'), on='user_name')

average_covid_tweets_by_friends = data_merged.groupby('user_friends')['covid_tweet_count'].mean().reset_index()


plt.figure(figsize=(10, 6))
sns.scatterplot(data=average_covid_tweets_by_friends, x='user_friends', y='covid_tweet_count', alpha=0.6)
plt.xscale('log') 
plt.yscale('log')
plt.title('Relación entre Número de Amigos y Media de Tweets sobre COVID-19 por Usuario')
plt.xlabel('Número de Amigos (escala logarítmica)')
plt.ylabel('Media de Tweets sobre COVID-19 (escala logarítmica)')
plt.show()

data['mentions_covid'] = data['text'].str.contains('covid|COVID|Covid', na=False) | data['hashtags'].str.contains('covid|COVID|Covid', na=False)

covid_tweets_by_verification = data.groupby('user_verified')['mentions_covid'].sum()

total_tweets_by_verification = data.groupby('user_verified').size()

proportion_of_covid_tweets = covid_tweets_by_verification / total_tweets_by_verification
percent_covid_verified = proportion_of_covid_tweets[True] * 100
percent_covid_non_verified = proportion_of_covid_tweets[False] * 100
print("Porcentaje de tweets sobre COVID-19 por usuarios verificados: {:.2f}%".format(percent_covid_verified))
print("Porcentaje de tweets sobre COVID-19 por usuarios no verificados: {:.2f}%".format(percent_covid_non_verified))